export const EMAIL_CONFIG = {
  SERVICE_ID: 'service_genindo',  // Replace with your EmailJS service ID
  TEMPLATE_ID: 'template_genindo', // Replace with your EmailJS template ID
  PUBLIC_KEY: 'Nw3QDxxx_xxx_xxxxxxxxxxxx' // Replace with your EmailJS public key
};